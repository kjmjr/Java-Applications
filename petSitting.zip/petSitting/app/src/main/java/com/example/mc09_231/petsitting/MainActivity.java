package com.example.mc09_231.petsitting;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //created an instance of the button
        Button b = findViewById(R.id.btnView);
        b.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                startActivity(new Intent(MainActivity.this,CompanyScreen.class));


            }//end public void
        });

    }//end protected void

}//end class
