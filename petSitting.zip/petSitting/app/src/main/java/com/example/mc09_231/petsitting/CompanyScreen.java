package com.example.mc09_231.petsitting;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CompanyScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_screen);
    }//end protected void

}//end class
